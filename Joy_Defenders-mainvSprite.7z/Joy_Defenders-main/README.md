# Universidade de Fortaleza

- Ciências da Computação, 2º Semestre, ano de 2024
- Experimentação de Protótipos (T166)
- Alunos integrantes:
    - Ana Laura Saraiva Borges
    - Gustavo Macedo
    - João Victor Cunha de Castro
    - João Victor Sampaio Silva Teixeira
